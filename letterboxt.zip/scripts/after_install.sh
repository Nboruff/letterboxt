#!/bin/bash
cd /var/www/html/letterboxt/
npm install
npm install --save react react-dom react-scripts react-particles-js
npm install pm2 -g
