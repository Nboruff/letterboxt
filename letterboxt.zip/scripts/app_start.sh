#!/bin/bash
cd /var/www/html/letterboxt/
npm runs start  > /dev/null 2>&1 &
