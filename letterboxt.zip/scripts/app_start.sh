#!/bin/bash
cd /home/ec2-user/server/src
npm runs start  > /dev/null 2>&1 &
