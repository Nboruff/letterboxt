#!/bin/bash
cd /home/ec2-user/server/src
npm start
