import React, { Component } from "react";

class Home extends Component {
    render() {
        return (
            <div>
                <h2>HELLO</h2>
                <p>here is some text</p>
            </div>
        );
    }
}

export default Home;