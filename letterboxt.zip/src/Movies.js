import React, { Component } from "react";

class Movies extends Component {
    render() {
        return (
            <div>
                <h2>MOVIES</h2>
                <p>Movies can go here!</p>
                <ol>
                    <li>Movie 1</li>
                    <li>Movie 2</li>
                    <li>Movie 3</li>
                </ol>
            </div>
        );
    }
}

export default Movies;