import React, { Component } from "react";

class Contact extends Component {
    render(){
        return (
            <div>
                <h2>GOT QUESTIONS?</h2>
                <p>Go to the <a href="tmdb.org">TMDB</a> website</p>
            </div>
        );
    }
}

export default Contact;